﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1_
{
    internal class InvalidRadiusException : Exception
    {
        public InvalidRadiusException(double radius) : base($"The radius value {radius} is not valid. Please enter a value greater than zero")
        {

        }
    }
}

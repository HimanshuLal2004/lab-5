﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Circle c1 = new Circle();
                c1.SetRadius(20);
                Console.WriteLine(c1.ToString());
            }
            catch(InvalidRadiusException re)
            {
                Console.WriteLine($"Error: {re.Message}");
            }
            try
            {
                Circle c2 = new Circle(-15);
                Console.WriteLine(c2.ToString());
            }
            catch (InvalidRadiusException re)
            {
                Console.WriteLine($"Error: {re.Message}");
            }
            try
            {
                Circle c3 = new Circle();
                c3.SetRadius(0);
                Console.WriteLine(c3.ToString());
            }
            catch(InvalidRadiusException re)
            {
                Console.WriteLine($"Error: {re.Message}");
            }
            Console.ReadKey();
        }

    }
}

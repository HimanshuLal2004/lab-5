﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1_
{
    class Circle
    {
        private double Radius;

        public Circle() { }
        public Circle(double radius)
        {
            if(radius > 0)
            {
                Radius = radius;
            }
            else
            {
                throw new InvalidRadiusException(radius);
            }
        }
        
        public void SetRadius(double radius)
        {
            if(radius > 0)
            {
                Radius = radius;
            }
            else
            {
                throw new InvalidRadiusException(radius);
            }
        }
        public override string ToString()
        {
            return $"The radius of the circle is : {Radius}";
        }

    }
}
